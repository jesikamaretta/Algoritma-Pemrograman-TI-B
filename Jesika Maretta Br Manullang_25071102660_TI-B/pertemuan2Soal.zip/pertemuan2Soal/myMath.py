def penjumlahan():
    return()